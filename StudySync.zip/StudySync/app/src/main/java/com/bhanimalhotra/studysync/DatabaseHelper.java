package com.bhanimalhotra.studysync;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudySync.db";
    private static final int DATABASE_VERSION = 6;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS assignments (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "title TEXT, subject TEXT, date TEXT, time TEXT, " +
                        "priority TEXT, completed TEXT)"
        );


        db.execSQL(
                "CREATE TABLE IF NOT EXISTS users (" +
                        "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "name TEXT, " +
                        "email TEXT UNIQUE, " +
                        "password TEXT, " +
                        "course TEXT DEFAULT 'B.Tech CSE (Data Science)', " +
                        "current_semester INTEGER DEFAULT 5)"
        );

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS subjects (" +
                        "subject_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "subject_name TEXT NOT NULL, " +
                        "faculty TEXT, semester INTEGER)"
        );

        createAcademicTable(db);
        createResultTable(db);
    }

    private void createAcademicTable(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS academic_info (" +
                        "academic_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "subject_id INTEGER NOT NULL, " +
                        "attended_classes INTEGER DEFAULT 0, " +
                        "total_classes INTEGER DEFAULT 0, " +
                        "internal_marks REAL DEFAULT 0, " +
                        "external_marks REAL DEFAULT 0, " +
                        "UNIQUE(user_id, subject_id))"
        );
    }

    private void createResultTable(SQLiteDatabase db) {

        db.execSQL(
                "CREATE TABLE IF NOT EXISTS subject_results (" +
                        "result_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "subject_id INTEGER NOT NULL, " +
                        "credits REAL, grade_point REAL, " +
                        "UNIQUE(user_id, subject_id))"
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        if (oldVersion < 2) {
            db.execSQL(
                    "CREATE TABLE IF NOT EXISTS users (" +
                            "user_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "name TEXT, email TEXT UNIQUE, password TEXT)"
            );
        }

        if (oldVersion < 3) {
            db.execSQL(
                    "CREATE TABLE IF NOT EXISTS subjects (" +
                            "subject_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            "user_id INTEGER NOT NULL, " +
                            "subject_name TEXT NOT NULL, " +
                            "faculty TEXT, semester INTEGER)"
            );
        }

        if (oldVersion < 4) {
            createAcademicTable(db);
        }

        if (oldVersion < 5) {
            createResultTable(db);
        }


        if (oldVersion < 6) {

            db.execSQL(
                    "ALTER TABLE users ADD COLUMN " +
                            "course TEXT DEFAULT 'B.Tech CSE (Data Science)'"
            );

            db.execSQL(
                    "ALTER TABLE users ADD COLUMN " +
                            "current_semester INTEGER DEFAULT 5"
            );
        }
    }

    private ContentValues assignmentValues(
            String title,
            String subject,
            String date,
            String time,
            String priority,
            String completed) {

        ContentValues values = new ContentValues();

        values.put("title", title);
        values.put("subject", subject);
        values.put("date", date);
        values.put("time", time);
        values.put("priority", priority);
        values.put("completed", completed);

        return values;
    }

    public boolean insertAssignment(
            String title,
            String subject,
            String date,
            String time,
            String priority,
            String completed) {

        return getWritableDatabase().insert(
                "assignments",
                null,
                assignmentValues(
                        title, subject, date,
                        time, priority, completed
                )
        ) != -1;
    }

    public Cursor getAllAssignments() {

        return getReadableDatabase().rawQuery(
                "SELECT * FROM assignments ORDER BY " +
                        "CASE WHEN LOWER(TRIM(completed)) " +
                        "IN ('yes','true','1','completed') " +
                        "THEN 1 ELSE 0 END ASC, " +
                        "CASE " +
                        "WHEN LOWER(TRIM(priority))='high' THEN 1 " +
                        "WHEN LOWER(TRIM(priority))='medium' THEN 2 " +
                        "WHEN LOWER(TRIM(priority)) IN ('low','easy') THEN 3 " +
                        "ELSE 4 END ASC, id DESC",
                null
        );
    }

    public Cursor getAssignmentById(int id) {

        return getReadableDatabase().rawQuery(
                "SELECT * FROM assignments WHERE id=?",
                new String[]{String.valueOf(id)}
        );
    }

    public boolean updateAssignment(
            int id,
            String title,
            String subject,
            String date,
            String time,
            String priority,
            String completed) {

        return getWritableDatabase().update(
                "assignments",
                assignmentValues(
                        title, subject, date,
                        time, priority, completed
                ),
                "id=?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    public boolean deleteAssignment(int id) {

        return getWritableDatabase().delete(
                "assignments",
                "id=?",
                new String[]{String.valueOf(id)}
        ) > 0;
    }

    // USERS

    private String hashPassword(String password) {

        try {

            byte[] digest = MessageDigest
                    .getInstance("SHA-256")
                    .digest(
                            password.getBytes(StandardCharsets.UTF_8)
                    );

            StringBuilder result = new StringBuilder();

            for (byte b : digest) {
                result.append(
                        String.format(Locale.US, "%02x", b & 0xff)
                );
            }

            return result.toString();

        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    public boolean registerUser(
            String name,
            String email,
            String password) {

        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("email", email.trim().toLowerCase(Locale.US));
        values.put("password", hashPassword(password));

        return getWritableDatabase().insert(
                "users", null, values
        ) != -1;
    }

    public boolean checkUser(
            String email,
            String password) {

        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT user_id FROM users " +
                        "WHERE email=? AND password=?",
                new String[]{
                        email.trim().toLowerCase(Locale.US),
                        hashPassword(password)
                })) {

            return cursor.moveToFirst();
        }
    }

    public String getUserName(String email) {

        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT name FROM users WHERE email=?",
                new String[]{
                        email.trim().toLowerCase(Locale.US)
                })) {

            return cursor.moveToFirst()
                    ? cursor.getString(0)
                    : "";
        }
    }

    public int getUserId(String email) {

        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT user_id FROM users WHERE email=?",
                new String[]{
                        email.trim().toLowerCase(Locale.US)
                })) {

            return cursor.moveToFirst()
                    ? cursor.getInt(0)
                    : -1;
        }
    }

    // SUBJECTS

    public boolean addSubject(
            int userId,
            String name,
            String faculty,
            int semester) {

        ContentValues values = new ContentValues();

        values.put("user_id", userId);
        values.put("subject_name", name);
        values.put("faculty", faculty);
        values.put("semester", semester);

        return getWritableDatabase().insert(
                "subjects", null, values
        ) != -1;
    }

    public Cursor getSubjects(int userId) {

        return getReadableDatabase().rawQuery(
                "SELECT * FROM subjects " +
                        "WHERE user_id=? ORDER BY subject_id",
                new String[]{String.valueOf(userId)}
        );
    }

    public Cursor getSubjectById(
            int subjectId,
            int userId) {

        return getReadableDatabase().rawQuery(
                "SELECT * FROM subjects " +
                        "WHERE subject_id=? AND user_id=?",
                new String[]{
                        String.valueOf(subjectId),
                        String.valueOf(userId)
                }
        );
    }

    public boolean updateSubject(
            int subjectId,
            int userId,
            String name,
            String faculty,
            int semester) {

        ContentValues values = new ContentValues();

        values.put("subject_name", name);
        values.put("faculty", faculty);
        values.put("semester", semester);

        return getWritableDatabase().update(
                "subjects",
                values,
                "subject_id=? AND user_id=?",
                new String[]{
                        String.valueOf(subjectId),
                        String.valueOf(userId)
                }
        ) > 0;
    }

    public boolean deleteSubject(
            int subjectId,
            int userId) {

        SQLiteDatabase db = getWritableDatabase();

        db.beginTransaction();

        try {

            String[] args = {
                    String.valueOf(userId),
                    String.valueOf(subjectId)
            };

            int deleted = db.delete(
                    "subjects",
                    "user_id=? AND subject_id=?",
                    args
            );

            if (deleted > 0) {

                db.delete(
                        "academic_info",
                        "user_id=? AND subject_id=?",
                        args
                );

                db.delete(
                        "subject_results",
                        "user_id=? AND subject_id=?",
                        args
                );
            }

            db.setTransactionSuccessful();

            return deleted > 0;

        } finally {
            db.endTransaction();
        }
    }

    public Cursor getSubjectsForSemester(
            int userId,
            int semester) {

        return getReadableDatabase().rawQuery(
                "SELECT subject_id, subject_name " +
                        "FROM subjects WHERE user_id=? AND semester=? " +
                        "ORDER BY subject_id",
                new String[]{
                        String.valueOf(userId),
                        String.valueOf(semester)
                }
        );
    }

    // ACADEMIC INFORMATION

    // Column positions:
    // 0 subject_id
    // 1 subject_name
    // 2 credits
    // 3 grade_point
    // 4 attended_classes
    // 5 total_classes
    // 6 internal_marks
    // 7 external_marks

    public Cursor getSemesterResults(
            int userId,
            int semester) {

        return getReadableDatabase().rawQuery(
                "SELECT s.subject_id, s.subject_name, " +
                        "r.credits, r.grade_point, " +
                        "a.attended_classes, a.total_classes, " +
                        "a.internal_marks, a.external_marks " +
                        "FROM subjects s " +
                        "LEFT JOIN subject_results r " +
                        "ON r.subject_id=s.subject_id " +
                        "AND r.user_id=s.user_id " +
                        "LEFT JOIN academic_info a " +
                        "ON a.subject_id=s.subject_id " +
                        "AND a.user_id=s.user_id " +
                        "WHERE s.user_id=? AND s.semester=? " +
                        "ORDER BY s.subject_id",
                new String[]{
                        String.valueOf(userId),
                        String.valueOf(semester)
                }
        );
    }

    private boolean ownsSubject(
            int userId,
            int subjectId) {

        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT 1 FROM subjects " +
                        "WHERE user_id=? AND subject_id=?",
                new String[]{
                        String.valueOf(userId),
                        String.valueOf(subjectId)
                })) {

            return cursor.moveToFirst();
        }
    }

    public boolean saveSubjectResult(
            int userId,
            int subjectId,
            double credits,
            double gradePoint) {

        if (!ownsSubject(userId, subjectId)
                || !Double.isFinite(credits)
                || credits <= 0
                || !Double.isFinite(gradePoint)
                || gradePoint < 0
                || gradePoint > 10) {

            return false;
        }

        ContentValues values = new ContentValues();

        values.put("user_id", userId);
        values.put("subject_id", subjectId);
        values.put("credits", credits);
        values.put("grade_point", gradePoint);

        return getWritableDatabase().insertWithOnConflict(
                "subject_results",
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE
        ) != -1;
    }

    public boolean saveAcademicInfo(
            int userId,
            int subjectId,
            int attended,
            int total,
            double internal,
            double external) {

        if (!ownsSubject(userId, subjectId)
                || attended < 0
                || total < attended
                || !Double.isFinite(internal)
                || !Double.isFinite(external)
                || internal < 0
                || external < 0) {

            return false;
        }

        ContentValues values = new ContentValues();

        values.put("user_id", userId);
        values.put("subject_id", subjectId);
        values.put("attended_classes", attended);
        values.put("total_classes", total);
        values.put("internal_marks", internal);
        values.put("external_marks", external);

        return getWritableDatabase().insertWithOnConflict(
                "academic_info",
                null,
                values,
                SQLiteDatabase.CONFLICT_REPLACE
        ) != -1;
    }

    public Cursor getAcademicInfo(
            int userId,
            int subjectId) {

        return getReadableDatabase().rawQuery(
                "SELECT * FROM academic_info " +
                        "WHERE user_id=? AND subject_id=?",
                new String[]{
                        String.valueOf(userId),
                        String.valueOf(subjectId)
                }
        );
    }

    private static final String[][] DEFAULT_SUBJECTS = {

            {"1", "Calculus (CAL)"},
            {"1", "English Communication (EC)"},
            {"1", "Basics of Electrical and Electronics Engineering (BEEE)"},
            {"1", "Programming for Problem Solving (PPS)"},
            {"1", "Engineering Graphics and Design (EGD)"},
            {"1", "Elements of Biology (EOB)"},
            {"1", "Professional Ethics (PE)"},
            {"1", "Constitution of India (COI)"},
            {"1", "Design Thinking (DT)"},

            {"2", "Linear Algebra and Differential Equations (LADE)"},
            {"2", "Physics (PHY)"},
            {"2", "Digital Circuits and Computer Architecture (DCCA)"},
            {"2", "Principles of Economics and Management (PEM)"},
            {"2", "Environmental Science (EVS)"},
            {"2", "Python for Data Analysis (PDA)"},
            {"2", "Digital Manufacturing Laboratory (DML)"},
            {"2", "Electrical and Electronics Workshop (EW)"},
            {"2", "Critical Thinking (CT)"},

            {"3", "Probability and Statistics (PS)"},
            {"3", "Data Wrangling (DW)"},
            {"3", "Optimization Methods (OM)"},
            {"3", "Discrete Mathematics (DM)"},
            {"3", "Data Structures and Algorithms (DSA)"},
            {"3", "Management Accounting for Engineers (MAE)"},
            {"3", "Technical Communication (TE)"},

            {"4", "Statistical Methods (SM)"},
            {"4", "Machine Learning (ML)"},
            {"4", "Introduction to Data Signal and Image Analysis (IDSIA)"},
            {"4", "Database Management Systems (DBMS)"},
            {"4", "Web Programming (WP)"},
            {"4", "Data Handling and Visualization (DHV)"},

            {"5", "Software Engineering (SE)", "Dr. Preetjot Kaur (PIK)"},
            {"5", "Mobile App. Development (MAD)", "Dr. Preetjot Kaur (PIK)"},
            {"5", "Operating System (OS)", "Dr. Aditya Bakshi (AB)"},
            {"5", "Computer Networks (CN)", "Dr. Aditya Bakshi (AB)"},
            {"5", "Data Driven Prog. Analysis (DDPA)", "Mr. Sandeep Kalra (SK)"},
            {"5", "Crypto. and Network Security (CNS)", "Ms. Sukhwant Kaur (SK)"},
            {"5", "Environment Management (EM)", "Ms. Trupti Gulhane (TG)"},
            {"5", "Elements of Project Manag. (EPM)", "Dr. Ashish Mogra (AM)"},
            {"5", "Disaster Management (DM)", "Dr. Ashish Mogra (AM)"},
            {"5", "Coursera", "Dr. Sanjeev Rao (SR)"}
    };

    public void insertDefaultSubjects(int userId) {

        if (userId < 1) {
            return;
        }

        SQLiteDatabase db = getWritableDatabase();

        db.beginTransaction();

        try {

            for (String[] item : DEFAULT_SUBJECTS) {

                int semester = Integer.parseInt(item[0]);
                String name = item[1];

                try (Cursor cursor = db.rawQuery(
                        "SELECT subject_id FROM subjects " +
                                "WHERE user_id=? AND semester=? " +
                                "AND LOWER(TRIM(subject_name))=" +
                                "LOWER(TRIM(?)) LIMIT 1",
                        new String[]{
                                String.valueOf(userId),
                                String.valueOf(semester),
                                name
                        })) {

                    if (cursor.moveToFirst()) {
                        continue;
                    }
                }

                ContentValues values = new ContentValues();

                values.put("user_id", userId);
                values.put("semester", semester);
                values.put("subject_name", name);

                values.put(
                        "faculty",
                        item.length > 2 ? item[2] : ""
                );

                db.insert("subjects", null, values);
            }

            db.setTransactionSuccessful();

        } finally {
            db.endTransaction();
        }
    }

    public Cursor getUserProfile(int userId) {

        return getReadableDatabase().rawQuery(
                "SELECT name, email, course, current_semester " +
                        "FROM users WHERE user_id=?",
                new String[]{String.valueOf(userId)}
        );
    }

    public boolean updateUserProfile(
            int userId,
            String name,
            String email,
            String course,
            int semester) {

        android.content.ContentValues values =
                new android.content.ContentValues();

        values.put("name", name.trim());
        values.put(
                "email",
                email.trim().toLowerCase(java.util.Locale.US)
        );
        values.put("course", course.trim());
        values.put("current_semester", semester);

        try {

            return getWritableDatabase().update(
                    "users",
                    values,
                    "user_id=?",
                    new String[]{String.valueOf(userId)}
            ) > 0;

        } catch (android.database.SQLException e) {

            return false;
        }
    }

    public boolean changePassword(
            int userId,
            String currentPassword,
            String newPassword) {

        String currentHash = hashPassword(currentPassword);

        try (Cursor cursor = getReadableDatabase().rawQuery(
                "SELECT user_id FROM users " +
                        "WHERE user_id=? AND password=?",
                new String[]{
                        String.valueOf(userId),
                        currentHash
                })) {

            if (!cursor.moveToFirst()) {
                return false;
            }
        }

        android.content.ContentValues values =
                new android.content.ContentValues();

        values.put(
                "password",
                hashPassword(newPassword)
        );

        return getWritableDatabase().update(
                "users",
                values,
                "user_id=?",
                new String[]{String.valueOf(userId)}
        ) > 0;
    }
}