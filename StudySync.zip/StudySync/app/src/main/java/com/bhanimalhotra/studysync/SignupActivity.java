package com.bhanimalhotra.studysync;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    EditText etName, etSignupEmail;
    EditText etSignupPassword, etConfirmPassword;
    Button btnSignup, btnBackToLogin;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etName = findViewById(R.id.etName);
        etSignupEmail = findViewById(R.id.etSignupEmail);
        etSignupPassword = findViewById(R.id.etSignupPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);

        btnSignup = findViewById(R.id.btnSignup);
        btnBackToLogin = findViewById(R.id.btnBackToLogin);

        databaseHelper = new DatabaseHelper(this);

        btnSignup.setOnClickListener(v -> createAccount());

        btnBackToLogin.setOnClickListener(v -> finish());
    }

    private void createAccount() {

        String name = etName.getText().toString().trim();
        String email = etSignupEmail.getText().toString().trim();
        String password = etSignupPassword.getText().toString();
        String confirmPassword =
                etConfirmPassword.getText().toString();

        if (name.isEmpty() || email.isEmpty()
                || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this,
                    "Please fill in all fields",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etSignupEmail.setError("Enter a valid email address");
            etSignupEmail.requestFocus();
            return;
        }

        if (password.length() < 8) {
            etSignupPassword.setError(
                    "Password must be at least 8 characters");
            etSignupPassword.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            etConfirmPassword.requestFocus();
            return;
        }

        boolean registered =
                databaseHelper.registerUser(name, email, password);

        if (registered) {
            Toast.makeText(this,
                    "Account created! Please log in.",
                    Toast.LENGTH_LONG).show();

            finish();
        } else {
            Toast.makeText(this,
                    "Account could not be created. This email may already be registered.",
                    Toast.LENGTH_LONG).show();
        }
    }
}