package com.bhanimalhotra.studysync;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etUsername, etPassword;
    Button btnLogin, btnGoToSignup;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        btnLogin = findViewById(R.id.btnLogin);
        btnGoToSignup = findViewById(R.id.btnGoToSignup);

        databaseHelper = new DatabaseHelper(this);

        // Login button
        btnLogin.setOnClickListener(v -> loginUser());

        // Open signup screen
        btnGoToSignup.setOnClickListener(v -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    SignupActivity.class
            );

            startActivity(intent);
        });
    }

    private void loginUser() {

        String email = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString();

        // Check empty fields
        if (email.isEmpty() || password.isEmpty()) {

            Toast.makeText(
                    this,
                    "Enter your email and password",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // Validate email
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

            etUsername.setError("Enter a valid email address");
            etUsername.requestFocus();

            return;
        }

        // Check credentials
        if (databaseHelper.checkUser(email, password)) {

            // Get student information
            String name = databaseHelper.getUserName(email);
            int userId = databaseHelper.getUserId(email);

            if (userId == -1) {

                Toast.makeText(
                        this,
                        "Unable to find student account",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Save logged-in student ID
            getSharedPreferences("StudySyncSession", MODE_PRIVATE)
                    .edit()
                    .putInt("user_id", userId)
                    .apply();

            Toast.makeText(
                    this,
                    "Login successful!",
                    Toast.LENGTH_SHORT
            ).show();

            // Open dashboard
            Intent intent = new Intent(
                    MainActivity.this,
                    DashboardActivity.class
            );

            intent.putExtra("student_name", name);

            startActivity(intent);
            finish();

        } else {

            Toast.makeText(
                    this,
                    "Incorrect email or password",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}