package com.bhanimalhotra.studysync;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private DatabaseHelper db;

    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dashboard);

        db = new DatabaseHelper(this);

        userId = getSharedPreferences(
                "StudySyncSession",
                MODE_PRIVATE
        ).getInt("user_id", -1);

        tvWelcome = findViewById(R.id.tvWelcome);

        Button btnAssignments =
                findViewById(R.id.btnAssignments);

        Button btnSubjects =
                findViewById(R.id.btnSubjects);

        Button btnAcademic =
                findViewById(R.id.btnAcademic);

        Button btnProfile =
                findViewById(R.id.btnProfile);

        btnAssignments.setOnClickListener(v -> {

            startActivity(new Intent(
                    this,
                    AssignmentActivity.class
            ));
        });

        btnSubjects.setOnClickListener(v -> {

            startActivity(new Intent(
                    this,
                    SubjectsActivity.class
            ));
        });

        btnAcademic.setOnClickListener(v -> {

            startActivity(new Intent(
                    this,
                    AcademicActivity.class
            ));
        });

        btnProfile.setOnClickListener(v -> {

            startActivity(new Intent(
                    this,
                    ProfileActivity.class
            ));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (userId < 1) {
            return;
        }

        try (Cursor cursor = db.getUserProfile(userId)) {

            if (cursor.moveToFirst()) {

                String fullName = cursor.getString(0);

                if (fullName != null &&
                        !fullName.trim().isEmpty()) {

                    String firstName =
                            fullName.trim().split("\\s+")[0];

                    tvWelcome.setText(
                            "Welcome, " + firstName + "! 👋"
                    );

                } else {

                    tvWelcome.setText(
                            "Welcome, Student! 👋"
                    );
                }
            }
        }
    }
}