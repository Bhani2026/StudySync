package com.bhanimalhotra.studysync;

import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

public class AcademicActivity extends AppCompatActivity {

    private DatabaseHelper db;

    private int userId;
    private int semester = 5;
    private int subjectId = -1;

    private Spinner spinnerSemester, spinnerSubjects;

    private TextView tvCgpa, tvGpa, tvSummary;
    private TextView tvCompletedSemesters;
    private TextView tvAttendance, tvStatus;

    private EditText etCredits, etGradePoint;
    private EditText etAttended, etTotal;
    private EditText etInternal, etExternal;

    private Button btnSaveGrade, btnSaveAcademic;

    private final ArrayList<Integer> ids = new ArrayList<>();
    private final ArrayList<String> names = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_academic);

        db = new DatabaseHelper(this);

        userId = getSharedPreferences(
                "StudySyncSession",
                MODE_PRIVATE
        ).getInt("user_id", -1);

        if (userId < 1) {
            Toast.makeText(
                    this,
                    "Please log in first",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
            return;
        }

        db.insertDefaultSubjects(userId);

        spinnerSemester = findViewById(R.id.spinnerSemester);
        spinnerSubjects = findViewById(R.id.spinnerSubjects);

        tvCgpa = findViewById(R.id.tvCgpa);
        tvGpa = findViewById(R.id.tvGpa);
        tvSummary = findViewById(R.id.tvSummary);

        tvCompletedSemesters =
                findViewById(R.id.tvCompletedSemesters);

        tvAttendance =
                findViewById(R.id.tvAttendancePercentage);

        tvStatus =
                findViewById(R.id.tvAttendanceStatus);

        etCredits = findViewById(R.id.etCredits);
        etGradePoint = findViewById(R.id.etGradePoint);

        etAttended = findViewById(R.id.etAttendedClasses);
        etTotal = findViewById(R.id.etTotalClasses);

        etInternal = findViewById(R.id.etInternalMarks);
        etExternal = findViewById(R.id.etExternalMarks);

        btnSaveGrade = findViewById(R.id.btnSaveGrade);
        btnSaveAcademic = findViewById(R.id.btnSaveAcademic);

        ArrayList<String> semesters = new ArrayList<>();

        for (int s = 1; s <= 5; s++) {
            semesters.add("Semester " + s);
        }

        ArrayAdapter<String> semesterAdapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        semesters
                );

        semesterAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerSemester.setAdapter(semesterAdapter);

        spinnerSemester.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        semester = position + 1;
                        subjectId = -1;

                        refreshAll();
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent) {
                    }
                }
        );

        spinnerSemester.setSelection(4);

        spinnerSubjects.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        if (position >= 0 &&
                                position < ids.size()) {

                            subjectId = ids.get(position);
                            loadSelectedSubject();
                        }
                    }

                    @Override
                    public void onNothingSelected(
                            AdapterView<?> parent) {

                        subjectId = -1;
                    }
                }
        );

        btnSaveGrade.setOnClickListener(
                v -> saveGrade()
        );

        btnSaveAcademic.setOnClickListener(
                v -> saveAttendanceMarks()
        );

        TextWatcher watcher = new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s,
                    int start,
                    int count,
                    int after) {
            }

            @Override
            public void onTextChanged(
                    CharSequence s,
                    int start,
                    int before,
                    int count) {

                previewAttendance();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };

        etAttended.addTextChangedListener(watcher);
        etTotal.addTextChangedListener(watcher);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (db != null &&
                userId > 0 &&
                spinnerSemester != null) {

            refreshAll();
        }
    }

    private void refreshAll() {

        refreshSubjectSpinner();
        calculateGpa();
        calculateCgpa();
    }

    // Load subjects for selected semester

    private void refreshSubjectSpinner() {

        int previousId = subjectId;

        ids.clear();
        names.clear();

        try (Cursor cursor =
                     db.getSubjectsForSemester(
                             userId,
                             semester
                     )) {

            while (cursor.moveToNext()) {

                ids.add(cursor.getInt(0));
                names.add(cursor.getString(1));
            }
        }

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        names
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerSubjects.setAdapter(adapter);

        boolean available = !ids.isEmpty();

        btnSaveGrade.setEnabled(available);
        btnSaveAcademic.setEnabled(available);

        if (available) {

            int index = ids.indexOf(previousId);

            if (index < 0) {
                index = 0;
            }

            subjectId = ids.get(index);

            spinnerSubjects.setSelection(index);

            loadSelectedSubject();

        } else {

            subjectId = -1;
            clearInputs();
        }
    }

    // Clear input fields

    private void clearInputs() {

        etCredits.setText("");
        etGradePoint.setText("");

        etAttended.setText("");
        etTotal.setText("");

        etInternal.setText("");
        etExternal.setText("");

        tvAttendance.setText("Attendance: --");

        tvStatus.setText("No attendance recorded");
        tvStatus.setTextColor(0xFF777184);
    }

    // Load saved subject information

    private void loadSelectedSubject() {

        clearInputs();

        if (subjectId < 1) {
            return;
        }

        try (Cursor cursor =
                     db.getSemesterResults(
                             userId,
                             semester
                     )) {

            while (cursor.moveToNext()) {

                if (cursor.getInt(0) != subjectId) {
                    continue;
                }

                if (!cursor.isNull(2)) {
                    etCredits.setText(
                            format(cursor.getDouble(2))
                    );
                }

                if (!cursor.isNull(3)) {
                    etGradePoint.setText(
                            format(cursor.getDouble(3))
                    );
                }

                if (!cursor.isNull(4)) {
                    etAttended.setText(
                            String.valueOf(cursor.getInt(4))
                    );
                }

                if (!cursor.isNull(5)) {
                    etTotal.setText(
                            String.valueOf(cursor.getInt(5))
                    );
                }

                if (!cursor.isNull(6)) {
                    etInternal.setText(
                            format(cursor.getDouble(6))
                    );
                }

                if (!cursor.isNull(7)) {
                    etExternal.setText(
                            format(cursor.getDouble(7))
                    );
                }

                break;
            }
        }

        previewAttendance();
    }

    // Calculate GPA using available subject grades

    private void calculateGpa() {

        int graded = 0;
        int total = 0;

        double credits = 0;
        double weighted = 0;

        try (Cursor cursor =
                     db.getSemesterResults(
                             userId,
                             semester
                     )) {

            while (cursor.moveToNext()) {

                total++;

                if (validGrade(cursor)) {

                    graded++;

                    double subjectCredits =
                            cursor.getDouble(2);

                    double gradePoint =
                            cursor.getDouble(3);

                    credits += subjectCredits;

                    weighted +=
                            subjectCredits * gradePoint;
                }
            }
        }

        if (credits > 0) {

            double gpa = weighted / credits;

            tvGpa.setText(format(gpa));

        } else {

            tvGpa.setText("--");
        }

        if (total == 0) {

            tvSummary.setText(
                    "No subjects in this semester"
            );

        } else if (graded == total) {

            tvSummary.setText(
                    "All " + total + " subjects graded"
            );

        } else {

            tvSummary.setText(
                    graded + "/" + total +
                            " subjects graded · Provisional GPA"
            );
        }
    }

    // Calculate CGPA using all available grades
    // from Semesters 1 to 5

    private void calculateCgpa() {

        double credits = 0;
        double weighted = 0;

        int semestersWithGrades = 0;
        int totalGradedSubjects = 0;
        int totalSubjects = 0;

        for (int s = 1; s <= 5; s++) {

            boolean hasGrade = false;

            try (Cursor cursor =
                         db.getSemesterResults(userId, s)) {

                while (cursor.moveToNext()) {

                    totalSubjects++;

                    if (validGrade(cursor)) {

                        hasGrade = true;
                        totalGradedSubjects++;

                        double subjectCredits =
                                cursor.getDouble(2);

                        double gradePoint =
                                cursor.getDouble(3);

                        credits += subjectCredits;

                        weighted +=
                                subjectCredits * gradePoint;
                    }
                }
            }

            if (hasGrade) {
                semestersWithGrades++;
            }
        }

        if (credits > 0) {

            double cgpa = weighted / credits;

            tvCgpa.setText(format(cgpa));

        } else {

            tvCgpa.setText("--");
        }

        String status = "Semesters with grades: " +
                semestersWithGrades + "/5";

        if (totalGradedSubjects < totalSubjects) {
            status += " · Provisional";
        }

        tvCompletedSemesters.setText(status);
    }

    // Check whether credits and grade point are valid

    private boolean validGrade(Cursor cursor) {

        if (cursor.isNull(2) || cursor.isNull(3)) {
            return false;
        }

        double credits = cursor.getDouble(2);
        double point = cursor.getDouble(3);

        return Double.isFinite(credits) &&
                Double.isFinite(point) &&
                credits > 0 &&
                point >= 0 &&
                point <= 10;
    }

    // Save credits and grade point

    private void saveGrade() {

        if (subjectId < 1) {
            Toast.makeText(
                    this,
                    "Select a subject first",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {

            double credits = Double.parseDouble(
                    etCredits.getText().toString().trim()
            );

            double point = Double.parseDouble(
                    etGradePoint.getText().toString().trim()
            );

            if (!Double.isFinite(credits) ||
                    credits <= 0 ||
                    !Double.isFinite(point) ||
                    point < 0 ||
                    point > 10) {

                Toast.makeText(
                        this,
                        "Credits must be positive; grade point must be 0–10",
                        Toast.LENGTH_LONG
                ).show();

                return;
            }

            boolean saved = db.saveSubjectResult(
                    userId,
                    subjectId,
                    credits,
                    point
            );

            if (saved) {

                Toast.makeText(
                        this,
                        "Grade saved successfully!",
                        Toast.LENGTH_SHORT
                ).show();

                calculateGpa();
                calculateCgpa();

            } else {

                Toast.makeText(
                        this,
                        "Unable to save grade",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException e) {

            Toast.makeText(
                    this,
                    "Enter valid credits and grade point",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Save attendance and marks together

    private void saveAttendanceMarks() {

        if (subjectId < 1) {
            Toast.makeText(
                    this,
                    "Select a subject first",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        try {

            String attendedText =
                    etAttended.getText().toString().trim();

            String totalText =
                    etTotal.getText().toString().trim();

            int attended = attendedText.isEmpty()
                    ? 0
                    : Integer.parseInt(attendedText);

            int total = totalText.isEmpty()
                    ? 0
                    : Integer.parseInt(totalText);

            String internalText =
                    etInternal.getText().toString().trim();

            String externalText =
                    etExternal.getText().toString().trim();

            double internal = internalText.isEmpty()
                    ? 0
                    : Double.parseDouble(internalText);

            double external = externalText.isEmpty()
                    ? 0
                    : Double.parseDouble(externalText);

            if (attended < 0 ||
                    total < attended ||
                    !Double.isFinite(internal) ||
                    !Double.isFinite(external) ||
                    internal < 0 ||
                    external < 0) {

                Toast.makeText(
                        this,
                        "Check attendance and marks values",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean saved = db.saveAcademicInfo(
                    userId,
                    subjectId,
                    attended,
                    total,
                    internal,
                    external
            );

            if (saved) {

                Toast.makeText(
                        this,
                        "Attendance and marks saved!",
                        Toast.LENGTH_SHORT
                ).show();

                previewAttendance();

            } else {

                Toast.makeText(
                        this,
                        "Unable to save details",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (NumberFormatException e) {

            Toast.makeText(
                    this,
                    "Enter valid attendance and marks",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // Attendance requirement: minimum 80%

    private void previewAttendance() {

        try {

            int attended = Integer.parseInt(
                    etAttended.getText().toString().trim()
            );

            int total = Integer.parseInt(
                    etTotal.getText().toString().trim()
            );

            if (attended < 0 || total < attended) {
                throw new NumberFormatException();
            }

            if (total == 0) {

                tvAttendance.setText("Attendance: --");
                tvStatus.setText("No classes recorded");
                tvStatus.setTextColor(0xFF777184);

                return;
            }

            double percentage =
                    100.0 * attended / total;

            tvAttendance.setText(
                    String.format(
                            Locale.US,
                            "Attendance: %.1f%%",
                            percentage
                    )
            );

            if (percentage >= 80) {

                tvStatus.setText("Good attendance!");
                tvStatus.setTextColor(0xFF2E7D32);

            } else {

                tvStatus.setText(
                        "Below required 80% attendance"
                );

                tvStatus.setTextColor(0xFFD84315);
            }

        } catch (NumberFormatException e) {

            tvAttendance.setText("Attendance: --");

            tvStatus.setText(
                    "Enter valid attendance values"
            );

            tvStatus.setTextColor(0xFF777184);
        }
    }

    private String format(double number) {

        return String.format(
                Locale.US,
                "%.2f",
                number
        );
    }
}
