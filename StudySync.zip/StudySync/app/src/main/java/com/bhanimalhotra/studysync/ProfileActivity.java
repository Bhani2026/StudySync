package com.bhanimalhotra.studysync;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ProfileActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private int userId;

    private TextView tvProfileName, tvProfileEmail;
    private EditText etName, etEmail, etCourse;
    private Spinner spinnerSemester;

    private Button btnSaveProfile;
    private Button btnChangePassword;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_profile);

        db = new DatabaseHelper(this);

        userId = getSharedPreferences(
                "StudySyncSession",
                MODE_PRIVATE
        ).getInt("user_id", -1);

        if (userId < 1) {
            goToLogin();
            return;
        }

        tvProfileName = findViewById(R.id.tvProfileName);
        tvProfileEmail = findViewById(R.id.tvProfileEmail);

        etName = findViewById(R.id.etProfileName);
        etEmail = findViewById(R.id.etProfileEmail);
        etCourse = findViewById(R.id.etProfileCourse);

        spinnerSemester =
                findViewById(R.id.spinnerProfileSemester);

        btnSaveProfile = findViewById(R.id.btnSaveProfile);
        btnChangePassword =
                findViewById(R.id.btnChangePassword);
        btnLogout = findViewById(R.id.btnLogout);

        ArrayList<String> semesters = new ArrayList<>();

        for (int i = 1; i <= 8; i++) {
            semesters.add("Semester " + i);
        }

        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_item,
                        semesters
                );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerSemester.setAdapter(adapter);

        loadProfile();

        btnSaveProfile.setOnClickListener(
                v -> saveProfile()
        );

        btnChangePassword.setOnClickListener(
                v -> showChangePasswordDialog()
        );

        btnLogout.setOnClickListener(
                v -> confirmLogout()
        );
    }

    private void loadProfile() {

        try (Cursor cursor = db.getUserProfile(userId)) {

            if (cursor.moveToFirst()) {

                String name = cursor.getString(0);
                String email = cursor.getString(1);
                String course = cursor.getString(2);
                int semester = cursor.getInt(3);

                tvProfileName.setText(name);
                tvProfileEmail.setText(email);

                etName.setText(name);
                etEmail.setText(email);
                etCourse.setText(course);

                if (semester >= 1 && semester <= 8) {
                    spinnerSemester.setSelection(semester - 1);
                }
            }
        }
    }

    private void saveProfile() {

        String name =
                etName.getText().toString().trim();

        String email =
                etEmail.getText().toString().trim();

        String course =
                etCourse.getText().toString().trim();

        int semester =
                spinnerSemester.getSelectedItemPosition() + 1;

        if (name.isEmpty()) {
            etName.setError("Enter your name");
            return;
        }

        if (email.isEmpty() ||
                !android.util.Patterns.EMAIL_ADDRESS
                        .matcher(email).matches()) {

            etEmail.setError("Enter a valid email");
            return;
        }

        if (course.isEmpty()) {
            etCourse.setError("Enter your course");
            return;
        }

        boolean updated = db.updateUserProfile(
                userId,
                name,
                email,
                course,
                semester
        );

        if (updated) {

            Toast.makeText(
                    this,
                    "Profile updated successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            loadProfile();

        } else {

            Toast.makeText(
                    this,
                    "Unable to update profile. Email may already exist.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void showChangePasswordDialog() {

        LinearLayout layout = new LinearLayout(this);

        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 16, 48, 0);

        EditText etCurrent = new EditText(this);
        etCurrent.setHint("Current Password");
        etCurrent.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        EditText etNew = new EditText(this);
        etNew.setHint("New Password");
        etNew.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        EditText etConfirm = new EditText(this);
        etConfirm.setHint("Confirm New Password");
        etConfirm.setInputType(
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        layout.addView(etCurrent);
        layout.addView(etNew);
        layout.addView(etConfirm);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Change Password")
                .setView(layout)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Update", null)
                .create();

        dialog.setOnShowListener(d -> {

            dialog.getButton(
                    AlertDialog.BUTTON_POSITIVE
            ).setOnClickListener(v -> {

                String current =
                        etCurrent.getText().toString();

                String newPassword =
                        etNew.getText().toString();

                String confirm =
                        etConfirm.getText().toString();

                if (current.isEmpty()) {
                    etCurrent.setError("Enter current password");
                    return;
                }

                if (newPassword.length() < 6) {
                    etNew.setError("Minimum 6 characters");
                    return;
                }

                if (!newPassword.equals(confirm)) {
                    etConfirm.setError("Passwords do not match");
                    return;
                }

                boolean changed = db.changePassword(
                        userId,
                        current,
                        newPassword
                );

                if (changed) {

                    Toast.makeText(
                            this,
                            "Password changed successfully!",
                            Toast.LENGTH_SHORT
                    ).show();

                    dialog.dismiss();

                } else {

                    etCurrent.setError(
                            "Current password is incorrect"
                    );
                }
            });
        });

        dialog.show();
    }

    private void confirmLogout() {

        new AlertDialog.Builder(this)
                .setTitle("Logout")
                .setMessage(
                        "Are you sure you want to log out?"
                )
                .setPositiveButton(
                        "Logout",
                        (dialog, which) -> logout()
                )
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void logout() {

        getSharedPreferences(
                "StudySyncSession",
                MODE_PRIVATE
        ).edit().clear().apply();

        goToLogin();
    }

    private void goToLogin() {

        Intent intent = new Intent(
                this,
                MainActivity.class
        );

        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        startActivity(intent);
        finish();
    }
}