package com.bhanimalhotra.studysync;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class AssignmentActivity extends AppCompatActivity {

    EditText etTitle, etSubject, etDate, etTime;
    RadioGroup rgPriority;
    RadioButton rbLow, rbMedium, rbHigh;
    CheckBox cbCompleted;
    Button btnSave, btnView;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignment);

        // Connect XML components
        etTitle = findViewById(R.id.etTitle);
        etSubject = findViewById(R.id.etSubject);
        etDate = findViewById(R.id.etDate);
        etTime = findViewById(R.id.etTime);

        rgPriority = findViewById(R.id.rgPriority);
        rbLow = findViewById(R.id.rbLow);
        rbMedium = findViewById(R.id.rbMedium);
        rbHigh = findViewById(R.id.rbHigh);

        cbCompleted = findViewById(R.id.cbCompleted);

        btnSave = findViewById(R.id.btnSave);
        btnView = findViewById(R.id.btnView);

        databaseHelper = new DatabaseHelper(this);

        // Date Picker
        etDate.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog =
                    new DatePickerDialog(
                            AssignmentActivity.this,
                            (view, selectedYear, selectedMonth, selectedDay) -> {

                                String date = selectedDay + "/" +
                                        (selectedMonth + 1) + "/" +
                                        selectedYear;

                                etDate.setText(date);
                            },
                            year,
                            month,
                            day
                    );

            datePickerDialog.show();
        });

        // Time Picker
        etTime.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog =
                    new TimePickerDialog(
                            AssignmentActivity.this,
                            (view, selectedHour, selectedMinute) -> {

                                String time = String.format(
                                        "%02d:%02d",
                                        selectedHour,
                                        selectedMinute
                                );

                                etTime.setText(time);
                            },
                            hour,
                            minute,
                            true
                    );

            timePickerDialog.show();
        });

        // Save Assignment
        btnSave.setOnClickListener(v -> saveAssignment());

        // View Assignments
        btnView.setOnClickListener(v -> {

            Intent intent = new Intent(
                    AssignmentActivity.this,
                    ViewAssignmentsActivity.class
            );

            startActivity(intent);
        });
    }

    private void saveAssignment() {

        String title = etTitle.getText().toString().trim();
        String subject = etSubject.getText().toString().trim();
        String date = etDate.getText().toString().trim();
        String time = etTime.getText().toString().trim();

        // Validation
        if (title.isEmpty()) {
            etTitle.setError("Enter assignment title");
            etTitle.requestFocus();
            return;
        }

        if (subject.isEmpty()) {
            etSubject.setError("Enter subject");
            etSubject.requestFocus();
            return;
        }

        if (date.isEmpty()) {
            Toast.makeText(
                    this,
                    "Select due date",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (time.isEmpty()) {
            Toast.makeText(
                    this,
                    "Select due time",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Get Priority
        String priority = "Medium";

        int selectedId = rgPriority.getCheckedRadioButtonId();

        if (selectedId == R.id.rbLow) {
            priority = "Low";
        } else if (selectedId == R.id.rbHigh) {
            priority = "High";
        }

        // Get completion status
        String completed = cbCompleted.isChecked()
                ? "Completed"
                : "Pending";

        // Insert into SQLite
        boolean inserted = databaseHelper.insertAssignment(
                title,
                subject,
                date,
                time,
                priority,
                completed
        );

        if (inserted) {

            Toast.makeText(
                    this,
                    "Assignment saved successfully",
                    Toast.LENGTH_SHORT
            ).show();

            clearFields();

        } else {

            Toast.makeText(
                    this,
                    "Failed to save assignment",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void clearFields() {

        etTitle.setText("");
        etSubject.setText("");
        etDate.setText("");
        etTime.setText("");

        rbMedium.setChecked(true);
        cbCompleted.setChecked(false);
    }
}