package com.bhanimalhotra.studysync;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddSubjectActivity extends AppCompatActivity {

    EditText etSubjectName, etFacultyName, etSemester;
    Button btnSaveSubject;
    TextView tvSubjectFormTitle;

    DatabaseHelper databaseHelper;

    int userId;
    int subjectId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_subject);

        etSubjectName = findViewById(R.id.etSubjectName);
        etFacultyName = findViewById(R.id.etFacultyName);
        etSemester = findViewById(R.id.etSemester);
        btnSaveSubject = findViewById(R.id.btnSaveSubject);
        tvSubjectFormTitle = findViewById(R.id.tvSubjectFormTitle);

        databaseHelper = new DatabaseHelper(this);

        userId = getSharedPreferences("StudySyncSession", MODE_PRIVATE)
                .getInt("user_id", -1);

        if (userId == -1) {
            Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        subjectId = getIntent().getIntExtra("subject_id", -1);

        // Editing an existing subject
        if (subjectId != -1) {

            tvSubjectFormTitle.setText("Edit Subject");
            btnSaveSubject.setText("Update Subject");

            Cursor cursor = databaseHelper.getSubjectById(subjectId, userId);

            try {
                if (cursor.moveToFirst()) {
                    etSubjectName.setText(cursor.getString(2));
                    etFacultyName.setText(cursor.getString(3));
                    etSemester.setText(String.valueOf(cursor.getInt(4)));
                } else {
                    Toast.makeText(this, "Subject not found", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
            } finally {
                cursor.close();
            }
        }

        btnSaveSubject.setOnClickListener(v -> saveSubject());
    }

    private void saveSubject() {

        String name = etSubjectName.getText().toString().trim();
        String faculty = etFacultyName.getText().toString().trim();
        String semesterText = etSemester.getText().toString().trim();

        if (name.isEmpty()) {
            etSubjectName.setError("Enter subject name");
            return;
        }

        if (semesterText.isEmpty()) {
            etSemester.setError("Enter semester");
            return;
        }

        int semester;

        try {
            semester = Integer.parseInt(semesterText);
        } catch (NumberFormatException e) {
            etSemester.setError("Enter a valid semester");
            return;
        }

        if (semester < 1 || semester > 8) {
            etSemester.setError("Semester must be between 1 and 8");
            return;
        }

        boolean success;

        if (subjectId == -1) {

            success = databaseHelper.addSubject(
                    userId, name, faculty, semester
            );

        } else {

            success = databaseHelper.updateSubject(
                    subjectId, userId, name, faculty, semester
            );
        }

        if (success) {
            Toast.makeText(this, "Subject saved successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to save subject", Toast.LENGTH_SHORT).show();
        }
    }
}