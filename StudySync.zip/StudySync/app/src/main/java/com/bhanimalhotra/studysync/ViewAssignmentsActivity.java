package com.bhanimalhotra.studysync;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

public class ViewAssignmentsActivity extends AppCompatActivity {

    ListView listViewAssignments;
    DatabaseHelper databaseHelper;

    ArrayList<AssignmentItem> assignmentList;
    ArrayList<Integer> assignmentIds;

    ArrayAdapter<AssignmentItem> adapter;

    static class AssignmentItem {
        int id;
        String title, subject, date, time, priority, completed;

        AssignmentItem(int id, String title, String subject,
                       String date, String time,
                       String priority, String completed) {

            this.id = id;
            this.title = title;
            this.subject = subject;
            this.date = date;
            this.time = time;
            this.priority = priority;
            this.completed = completed;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_assignments);

        listViewAssignments = findViewById(R.id.listViewAssignments);
        databaseHelper = new DatabaseHelper(this);

        assignmentList = new ArrayList<>();
        assignmentIds = new ArrayList<>();

        // Display each assignment using a custom card
        adapter = new ArrayAdapter<AssignmentItem>(
                this, R.layout.item_assignment, assignmentList) {

            @NonNull
            @Override
            public View getView(int position,
                                @Nullable View convertView,
                                @NonNull ViewGroup parent) {

                View view = convertView;

                if (view == null) {
                    view = LayoutInflater.from(getContext())
                            .inflate(R.layout.item_assignment, parent, false);
                }

                AssignmentItem item = getItem(position);

                TextView tvTitle = view.findViewById(R.id.tvAssignmentTitle);
                TextView tvSubject = view.findViewById(R.id.tvAssignmentSubject);
                TextView tvDue = view.findViewById(R.id.tvAssignmentDue);
                TextView tvPriority = view.findViewById(R.id.tvAssignmentPriority);
                TextView tvStatus = view.findViewById(R.id.tvAssignmentStatus);

                if (item != null) {

                    tvTitle.setText(item.title);
                    tvSubject.setText("Subject: " + item.subject);
                    tvDue.setText("Due: " + item.date + " | " + item.time);

                    String priority = item.priority == null
                            ? ""
                            : item.priority.trim().toLowerCase(Locale.ROOT);

                    switch (priority) {
                        case "high":
                            tvPriority.setText("● HIGH PRIORITY");
                            tvPriority.setTextColor(Color.parseColor("#E53935"));
                            break;

                        case "medium":
                            tvPriority.setText("● MEDIUM PRIORITY");
                            tvPriority.setTextColor(Color.parseColor("#F57C00"));
                            break;

                        case "low":
                        case "easy":
                            tvPriority.setText("● LOW PRIORITY");
                            tvPriority.setTextColor(Color.parseColor("#43A047"));
                            break;

                        default:
                            tvPriority.setText("● " + item.priority);
                            tvPriority.setTextColor(Color.parseColor("#655B78"));
                            break;
                    }

                    String status = item.completed == null
                            ? ""
                            : item.completed.trim().toLowerCase(Locale.ROOT);

                    boolean isCompleted =
                            status.equals("completed") ||
                                    status.equals("yes") ||
                                    status.equals("true") ||
                                    status.equals("1");

                    if (isCompleted) {
                        tvStatus.setText("✓ Completed");
                        tvStatus.setTextColor(Color.parseColor("#43A047"));
                    } else {
                        tvStatus.setText("◷ Pending");
                        tvStatus.setTextColor(Color.parseColor("#F57C00"));
                    }
                }

                return view;
            }
        };

        listViewAssignments.setAdapter(adapter);

        // Empty list message
        TextView emptyView = new TextView(this);
        emptyView.setText("No assignments yet!\nAdd your first assignment to get started.");
        emptyView.setTextSize(16);
        emptyView.setTextColor(Color.parseColor("#777184"));
        emptyView.setGravity(android.view.Gravity.CENTER);
        emptyView.setPadding(20, 60, 20, 20);

        ViewGroup parent = (ViewGroup) listViewAssignments.getParent();
        parent.addView(emptyView);

        listViewAssignments.setEmptyView(emptyView);

        // TAP TO EDIT
        listViewAssignments.setOnItemClickListener(
                (parentView, view, position, id) -> {

                    int assignmentId = assignmentIds.get(position);

                    Intent intent = new Intent(
                            ViewAssignmentsActivity.this,
                            EditAssignmentActivity.class
                    );

                    intent.putExtra("assignment_id", assignmentId);
                    startActivity(intent);
                }
        );

        // LONG PRESS TO DELETE
        listViewAssignments.setOnItemLongClickListener(
                (parentView, view, position, id) -> {

                    int assignmentId = assignmentIds.get(position);

                    new AlertDialog.Builder(ViewAssignmentsActivity.this)
                            .setTitle("Delete Assignment")
                            .setMessage("Do you want to delete this assignment?")
                            .setPositiveButton("Delete", (dialog, which) -> {

                                boolean deleted =
                                        databaseHelper.deleteAssignment(assignmentId);

                                if (deleted) {
                                    Toast.makeText(
                                            ViewAssignmentsActivity.this,
                                            "Assignment deleted",
                                            Toast.LENGTH_SHORT
                                    ).show();

                                    loadAssignments();

                                } else {
                                    Toast.makeText(
                                            ViewAssignmentsActivity.this,
                                            "Failed to delete assignment",
                                            Toast.LENGTH_SHORT
                                    ).show();
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();

                    return true;
                }
        );

        loadAssignments();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (databaseHelper != null && adapter != null) {
            loadAssignments();
        }
    }

    private void loadAssignments() {

        assignmentList.clear();
        assignmentIds.clear();

        Cursor cursor = databaseHelper.getAllAssignments();

        try {
            while (cursor.moveToNext()) {

                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String subject = cursor.getString(2);
                String date = cursor.getString(3);
                String time = cursor.getString(4);
                String priority = cursor.getString(5);
                String completed = cursor.getString(6);

                assignmentIds.add(id);

                assignmentList.add(new AssignmentItem(
                        id, title, subject, date,
                        time, priority, completed
                ));
            }
        } finally {
            cursor.close();
        }

        adapter.notifyDataSetChanged();
    }
}