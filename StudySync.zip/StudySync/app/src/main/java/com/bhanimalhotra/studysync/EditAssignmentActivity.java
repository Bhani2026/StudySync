package com.bhanimalhotra.studysync;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class EditAssignmentActivity extends AppCompatActivity {

    EditText etEditTitle, etEditSubject, etEditDate, etEditTime;
    RadioGroup rgEditPriority;
    CheckBox cbEditCompleted;
    Button btnUpdate, btnCancel;

    DatabaseHelper databaseHelper;
    int assignmentId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_assignment);

        etEditTitle = findViewById(R.id.etEditTitle);
        etEditSubject = findViewById(R.id.etEditSubject);
        etEditDate = findViewById(R.id.etEditDate);
        etEditTime = findViewById(R.id.etEditTime);

        rgEditPriority = findViewById(R.id.rgEditPriority);
        cbEditCompleted = findViewById(R.id.cbEditCompleted);

        btnUpdate = findViewById(R.id.btnUpdate);
        btnCancel = findViewById(R.id.btnCancel);

        databaseHelper = new DatabaseHelper(this);

        assignmentId = getIntent().getIntExtra("assignment_id", -1);

        if (assignmentId == -1) {
            Toast.makeText(this, "Assignment not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        loadAssignment();

        etEditDate.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();

            DatePickerDialog dialog = new DatePickerDialog(
                    this,
                    (view, year, month, day) ->
                            etEditDate.setText(
                                    day + "/" + (month + 1) + "/" + year
                            ),
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            dialog.show();
        });

        etEditTime.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();

            TimePickerDialog dialog = new TimePickerDialog(
                    this,
                    (view, hour, minute) ->
                            etEditTime.setText(
                                    String.format("%02d:%02d", hour, minute)
                            ),
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    true
            );

            dialog.show();
        });

        btnUpdate.setOnClickListener(v -> updateAssignment());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void loadAssignment() {
        Cursor cursor = databaseHelper.getAssignmentById(assignmentId);

        if (cursor.moveToFirst()) {
            etEditTitle.setText(cursor.getString(1));
            etEditSubject.setText(cursor.getString(2));
            etEditDate.setText(cursor.getString(3));
            etEditTime.setText(cursor.getString(4));

            String priority = cursor.getString(5);

            if ("Low".equals(priority)) {
                rgEditPriority.check(R.id.rbEditLow);
            } else if ("High".equals(priority)) {
                rgEditPriority.check(R.id.rbEditHigh);
            } else {
                rgEditPriority.check(R.id.rbEditMedium);
            }

            cbEditCompleted.setChecked(
                    "Completed".equals(cursor.getString(6))
            );
        } else {
            Toast.makeText(this, "Assignment not found", Toast.LENGTH_SHORT).show();
            finish();
        }

        cursor.close();
    }

    private void updateAssignment() {
        String title = etEditTitle.getText().toString().trim();
        String subject = etEditSubject.getText().toString().trim();
        String date = etEditDate.getText().toString().trim();
        String time = etEditTime.getText().toString().trim();

        if (title.isEmpty()) {
            etEditTitle.setError("Enter assignment title");
            etEditTitle.requestFocus();
            return;
        }

        if (subject.isEmpty()) {
            etEditSubject.setError("Enter subject");
            etEditSubject.requestFocus();
            return;
        }

        if (date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Select due date and time", Toast.LENGTH_SHORT).show();
            return;
        }

        String priority;

        int selectedId = rgEditPriority.getCheckedRadioButtonId();

        if (selectedId == R.id.rbEditLow) {
            priority = "Low";
        } else if (selectedId == R.id.rbEditHigh) {
            priority = "High";
        } else {
            priority = "Medium";
        }

        String completed = cbEditCompleted.isChecked()
                ? "Completed"
                : "Pending";

        boolean updated = databaseHelper.updateAssignment(
                assignmentId,
                title,
                subject,
                date,
                time,
                priority,
                completed
        );

        if (updated) {
            Toast.makeText(this, "Assignment updated", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
        }
    }
}