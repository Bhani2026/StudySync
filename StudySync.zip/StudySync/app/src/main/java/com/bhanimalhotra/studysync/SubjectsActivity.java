package com.bhanimalhotra.studysync;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class SubjectsActivity extends AppCompatActivity {

    ListView listViewSubjects;
    Button btnAddSubject;

    DatabaseHelper databaseHelper;

    ArrayList<SubjectItem> subjectList;
    ArrayAdapter<SubjectItem> adapter;

    int userId;

    static class SubjectItem {

        int id, semester;
        String name, faculty;

        SubjectItem(int id, String name, String faculty, int semester) {
            this.id = id;
            this.name = name;
            this.faculty = faculty;
            this.semester = semester;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjects);

        listViewSubjects = findViewById(R.id.listViewSubjects);
        btnAddSubject = findViewById(R.id.btnAddSubject);

        databaseHelper = new DatabaseHelper(this);

        // Get logged-in student ID
        android.content.SharedPreferences preferences =
                getSharedPreferences("StudySyncSession", MODE_PRIVATE);

        userId = preferences.getInt("user_id", -1);

        if (userId == -1) {
            Toast.makeText(this, "Please log in first", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseHelper.insertDefaultSubjects(userId);

        subjectList = new ArrayList<>();

        adapter = new ArrayAdapter<SubjectItem>(
                this, R.layout.item_subject, subjectList) {

            @NonNull
            @Override
            public View getView(int position,
                                @Nullable View convertView,
                                @NonNull ViewGroup parent) {

                View view = convertView;

                if (view == null) {
                    view = LayoutInflater.from(getContext())
                            .inflate(R.layout.item_subject, parent, false);
                }

                SubjectItem item = getItem(position);

                if (item != null) {

                    TextView tvName = view.findViewById(R.id.tvSubjectName);
                    TextView tvFaculty = view.findViewById(R.id.tvFaculty);
                    TextView tvSemester = view.findViewById(R.id.tvSemester);

                    tvName.setText(item.name);
                    tvFaculty.setText("Faculty: " + item.faculty);
                    tvSemester.setText("Semester " + item.semester);
                }

                return view;
            }
        };

        listViewSubjects.setAdapter(adapter);

        btnAddSubject.setOnClickListener(v -> {
            Intent intent = new Intent(
                    SubjectsActivity.this,
                    AddSubjectActivity.class
            );
            startActivity(intent);
        });

        // Tap to edit
        listViewSubjects.setOnItemClickListener((parent, view, position, id) -> {

            SubjectItem item = subjectList.get(position);

            Intent intent = new Intent(
                    SubjectsActivity.this,
                    AddSubjectActivity.class
            );

            intent.putExtra("subject_id", item.id);
            startActivity(intent);
        });

        // Long press to delete
        listViewSubjects.setOnItemLongClickListener((parent, view, position, id) -> {

            SubjectItem item = subjectList.get(position);

            new AlertDialog.Builder(this)
                    .setTitle("Delete Subject")
                    .setMessage("Delete " + item.name + "?")
                    .setPositiveButton("Delete", (dialog, which) -> {

                        if (databaseHelper.deleteSubject(item.id, userId)) {
                            Toast.makeText(this, "Subject deleted", Toast.LENGTH_SHORT).show();
                            loadSubjects();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();

            return true;
        });

        loadSubjects();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (adapter != null) {
            loadSubjects();
        }
    }

    private void loadSubjects() {

        subjectList.clear();

        Cursor cursor = databaseHelper.getSubjects(userId);

        try {
            while (cursor.moveToNext()) {

                subjectList.add(new SubjectItem(
                        cursor.getInt(0),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getInt(4)
                ));
            }
        } finally {
            cursor.close();
        }

        adapter.notifyDataSetChanged();
    }
}